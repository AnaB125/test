On Error Resume Next
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

startupFolder = shell.SpecialFolders("Startup") & "\"
sFilePath = "c:\dt_files\boot.vbs"
fso.CopyFile sFilePath, startupFolder 